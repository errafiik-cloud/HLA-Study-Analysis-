# Data dictionary

- SampleID: sample/patient identifier
- Locus: HLA-A, HLA-B or HLA-C
- Method1: POLYSOLVER
- Method2: OptiType
- M1_Allele1/2: POLYSOLVER allele calls
- M2_Allele1/2: OptiType allele calls
- Pairing: phase-insensitive allele pairing (1-1,2-2 or 1-2,2-1)
- Both_alleles_match_4digit: both alleles concordant at 4-field resolution
- Both_alleles_match_2digit: both alleles concordant at 2-field resolution
- Any_allele_match_4digit/2digit: at least one allele concordant
- LOH: locus-level HLA-LOH status; missing values are excluded from LOH analysis
