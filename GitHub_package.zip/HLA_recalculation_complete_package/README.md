# HLA-I Concordance Recalculation — Complete Package

This package contains the Python scripts, source data, recalculated results, publication-ready figures, and documentation for the germline-to-tumor HLA-I concordance analyses in the FUSCCTNBC and TNAC datasets.

## 1. Analysis scripts
- `scripts/01_concordance.py` — locus-level concordance.
- `scripts/02_concordance_CI.py` — 95% confidence intervals.
- `scripts/03_discordant_alleles.py` — discordant allele analysis.
- `scripts/04_patient_level.py` — individual-level concordance (0–6 matching alleles).
- `scripts/05_LOH_association.py` — HLA-LOH association and odds ratios with 95% CIs.
- `scripts/06_reproducibility.py` — reproducibility analyses.
- `scripts/07_allele_level_kappa.py` — reproducible categorical allele-level Cohen's kappa.
- `scripts/08_figure_matching_alleles.py` — figure generation.

`requirements.txt` lists the required Python packages.

## 2. Source data
- `data/FUSCCTNBC_HLA_dataset.xlsx` — FUSCCTNBC HLA-I dataset (n = 313 patients; 939 locus-level records).
- `data/TNAC_dataset.xlsx` — definitive TNAC dataset used for recalculation (n = 83 patients; Normal DNA, Tumor DNA and Tumor RNA).
- `data/FUSCCTNBC_Supplementary_Tables_X_and_S1.xlsx` — sequencing/reproducibility metadata.
- `data/DATA_DICTIONARY.md` — description of the FUSCCTNBC variables.

## 3. Recalculated results
`results/HLA_recalculated_results.xlsx` contains the consolidated recalculated results. Additional CSV files contain concordance summaries, confidence intervals, patient-level distributions, discordant alleles, kappa, and LOH analyses.

## 4. Figures
- `figures/Figure_HLA_concordance_comparison_2digit.png` — FUSCCTNBC vs TNAC, locus-level concordance at 2-digit resolution.
- `figures/Figure_HLA_concordance_comparison_4digit.png` — FUSCCTNBC vs TNAC, locus-level concordance at 4-digit resolution.
- `figures/Figure_individual_concordance_2digit.png` — individual-level distribution of 0–6 matching alleles at 2-digit resolution.
- `figures/Figure_individual_concordance_4digit.png` — individual-level distribution of 0–6 matching alleles at 4-digit resolution.

The underlying figure data are provided in `data/Figure_individual_concordance_data.xlsx` and `data/HLA_concordance_figure_data.xlsx`.

## 5. Important statistical note
The analyses report concordance, agreement and reproducibility rather than absolute HLA typing accuracy because no independent orthogonal clinical HLA typing reference was supplied. Historical Cohen's kappa values from earlier manuscript versions cannot be uniquely reconstructed from the stored match flags alone. The package therefore reports a reproducible allele-level categorical kappa separately and does not silently replace the historical statistic.

## 6. Definitions
- **Locus-level concordance:** at least one of the two alleles at a locus is concordant.
- **Complete individual-level concordance:** all six HLA-I alleles (two alleles each at HLA-A, HLA-B and HLA-C) are concordant.
- Two-field and four-field resolutions are analyzed separately.
- LOH association uses Fisher's exact test and odds ratios with 95% confidence intervals.

## 7. Re-running the analyses
From the package root, install the packages in `requirements.txt`, then run the scripts in numerical order as appropriate. The source workbooks should be kept unchanged to preserve reproducibility.

## 8. GitHub/reviewer reproducibility package
This repository is intended to accompany the manuscript revision and to provide transparent reproducibility materials requested during peer review. It includes the source datasets used for the recalculation, analysis scripts, derived statistical results, figure source data, and publication-ready figures.

### Figure 1
`figures/Figure_1_individual_concordance_square.png` and `.pdf` reproduce the revised individual-level figure in a 1:1 format:
- **A:** 2-digit (two-field) resolution.
- **B:** 4-digit (four-field) resolution.

The figure shows the percentage of individuals with 0–6 concordant alleles among the six HLA-I alleles (two alleles each at HLA-A, HLA-B and HLA-C).

### Important reproducibility statement
The TNAC workbook included in this repository is the definitive 83-patient workbook used for the current recalculation. Patient-level concordance distributions and locus-level concordance were recalculated directly from the stored allele calls. Historical values appearing in earlier manuscript versions should not be substituted for the recalculated values without verification against the source workbook.

### Running Figure 1
From the repository root:
```bash
python scripts/09_figure1_individual_concordance.py --outdir figures
```

### Suggested GitHub repository name
`HLA-I-typing-concordance`

### Suggested repository description
`Reproducible Python analyses, source data, statistical results, and figures for germline-to-tumor HLA-I typing concordance across FUSCCTNBC and TNAC datasets.`
