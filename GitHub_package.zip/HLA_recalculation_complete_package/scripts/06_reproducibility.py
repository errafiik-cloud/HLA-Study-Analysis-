#!/usr/bin/env python3
"""06_reproducibility.py
Template for summarising sequencing replicate/modality reproducibility.

Input CSV should contain one row per biological sample and binary concordance
columns. Adapt COLUMN_MAP to the actual reproducibility table.
"""

import argparse
from pathlib import Path
import pandas as pd
from statsmodels.stats.proportion import proportion_confint

COLUMN_MAP = {
    "RNA-seq replicate 1 vs 2": "RNAseq_replicate_concordant",
    "Tumor WES vs tumor RNA-seq": "WES_RNAseq_concordant",
}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()
    out = Path(args.outdir); out.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(args.input)

    rows = []
    for comparison, col in COLUMN_MAP.items():
        if col not in df.columns:
            continue
        s = df[col].dropna().astype(bool)
        k, n = int(s.sum()), len(s)
        lo, hi = proportion_confint(k, n, alpha=0.05, method="beta")
        rows.append({
            "Comparison": comparison, "Concordant": k, "N": n,
            "Percent": round(100*k/n,2),
            "CI95_lower": round(100*lo,2),
            "CI95_upper": round(100*hi,2)
        })
    pd.DataFrame(rows).to_csv(out/"reproducibility_summary.csv", index=False)

if __name__ == "__main__":
    main()
