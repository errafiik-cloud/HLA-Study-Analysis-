#!/usr/bin/env python3
"""01_concordance.py
Locus-level and overall HLA-I concordance at 2-field and 4-field resolution.
Input: HLA_dataset.xlsx, sheet 'detailed'.
"""

import argparse
from pathlib import Path
import pandas as pd

METRICS = {
    "Both alleles, 4-field": "Both_alleles_match_4digit",
    "Any allele, 4-field": "Any_allele_match_4digit",
    "Both alleles, 2-field": "Both_alleles_match_2digit",
    "Any allele, 2-field": "Any_allele_match_2digit",
}

def pct(s):
    return 100 * s.astype(bool).mean()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()
    out = Path(args.outdir); out.mkdir(parents=True, exist_ok=True)
    df = pd.read_excel(args.input, sheet_name="detailed")

    rows = []
    for locus in ["HLA-A", "HLA-B", "HLA-C"]:
        d = df[df["Locus"] == locus]
        row = {"Locus": locus, "N": d["SampleID"].nunique()}
        for label, col in METRICS.items():
            row[label] = round(pct(d[col]), 2)
        rows.append(row)

    overall = {"Locus": "Overall", "N": df["SampleID"].nunique()}
    for label, col in METRICS.items():
        overall[label] = round(pct(df[col]), 2)

    pd.DataFrame(rows + [overall]).to_csv(out/"concordance_summary.csv", index=False)
    print(pd.DataFrame(rows + [overall]).to_string(index=False))

if __name__ == "__main__":
    main()
