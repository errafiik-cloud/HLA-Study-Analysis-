#!/usr/bin/env python3
"""05_LOH_association.py
Association between locus-level HLA discordance and HLA-LOH.

This reproduces the 2x2 analysis when LOH is recorded in the 'LOH' column.
Rows with missing LOH are excluded.

The odds ratio is defined for:
LOH (yes) vs non_LOH, among discordant vs concordant HLA calls.
"""

import argparse
from pathlib import Path
import pandas as pd
from scipy.stats import fisher_exact
from statsmodels.stats.contingency_tables import Table2x2

def analyse(df, concordance_col):
    d = df[df["LOH"].notna()].copy()
    d["Discordant"] = ~d[concordance_col].astype(bool)

    tab = pd.crosstab(d["LOH"], d["Discordant"])
    tab = tab.reindex(index=["non_LOH","LOH"], columns=[False,True], fill_value=0)

    # Rows: non_LOH, LOH; columns: concordant, discordant
    arr = tab.to_numpy()
    OR, p = fisher_exact(arr)
    ci_low, ci_high = Table2x2(arr).oddsratio_confint(method="exact")

    return tab, OR, ci_low, ci_high, p

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()
    out = Path(args.outdir); out.mkdir(parents=True, exist_ok=True)
    df = pd.read_excel(args.input, sheet_name="detailed")

    results = []
    for resolution, col in [
        ("4-field","Both_alleles_match_4digit"),
        ("2-field","Both_alleles_match_2digit")
    ]:
        tab, OR, lo, hi, p = analyse(df, col)
        tab.to_csv(out/f"LOH_2x2_{resolution}.csv")
        results.append({
            "Resolution": resolution,
            "OR": round(OR, 3),
            "CI95_lower": round(lo, 3),
            "CI95_upper": round(hi, 3),
            "Fisher_p": round(p, 4)
        })
        print(f"\n{resolution}")
        print(tab)
        print(f"OR={OR:.3f}; 95% CI={lo:.3f}-{hi:.3f}; Fisher p={p:.4f}")

    pd.DataFrame(results).to_csv(out/"LOH_association.csv", index=False)

if __name__ == "__main__":
    main()
