#!/usr/bin/env python3
"""07_allele_level_kappa.py

Calculate Cohen's kappa from paired categorical allele calls after applying
the phase-insensitive Pairing field.

IMPORTANT:
This is categorical allele-call kappa. It should only be used as the
manuscript statistic if this is the same definition used in the study.
It is deliberately kept separate from the concordance scripts because
different kappa definitions can produce different values.
"""

import argparse
from pathlib import Path
import pandas as pd
from sklearn.metrics import cohen_kappa_score

def calls(df, resolution):
    x, y = [], []
    for _, r in df.iterrows():
        for pair in str(r["Pairing"]).split(","):
            i, j = map(int, pair.strip().split("-"))
            a, b = str(r[f"M1_Allele{i}"]), str(r[f"M2_Allele{j}"])
            if resolution == "2-field":
                a, b = a.split(":")[0], b.split(":")[0]
            x.append(a); y.append(b)
    return x, y

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()
    out = Path(args.outdir); out.mkdir(parents=True, exist_ok=True)
    df = pd.read_excel(args.input, sheet_name="detailed")

    rows = []
    for locus in ["HLA-A","HLA-B","HLA-C"]:
        d = df[df["Locus"] == locus]
        for res in ["2-field","4-field"]:
            x,y = calls(d,res)
            rows.append({"Locus":locus,"Resolution":res,
                         "Kappa":round(cohen_kappa_score(x,y),4),
                         "Allele_pairs":len(x)})
    pd.DataFrame(rows).to_csv(out/"allele_level_kappa.csv", index=False)

if __name__ == "__main__":
    main()
