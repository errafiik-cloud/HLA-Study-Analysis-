#!/usr/bin/env python3
"""03_discordant_alleles.py
Extract phase-insensitive allele discrepancies and classify them as:
same 2-field allele group vs different allele group.
"""

import argparse
from pathlib import Path
import pandas as pd

def group(a):
    return str(a).split(":")[0]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()
    out = Path(args.outdir); out.mkdir(parents=True, exist_ok=True)
    df = pd.read_excel(args.input, sheet_name="detailed")

    rec = []
    for _, r in df.iterrows():
        for pair in str(r["Pairing"]).split(","):
            i, j = map(int, pair.strip().split("-"))
            a = str(r[f"M1_Allele{i}"])
            b = str(r[f"M2_Allele{j}"])
            if a != b:
                rec.append({
                    "SampleID": r["SampleID"],
                    "Locus": r["Locus"],
                    "Method1": a,
                    "Method2": b,
                    "Method1_group": group(a),
                    "Method2_group": group(b),
                    "Same_2field_group": group(a) == group(b)
                })

    disc = pd.DataFrame(rec)
    disc.to_csv(out/"discordant_alleles.csv", index=False)

    if not disc.empty:
        summary = (disc.groupby(
            ["Locus","Method1","Method2","Same_2field_group"],
            dropna=False).size().reset_index(name="Count")
                  .sort_values("Count", ascending=False))
        summary.to_csv(out/"discordant_allele_pairs.csv", index=False)

        grouped = (disc.groupby(["Locus","Same_2field_group"])
                   .size().reset_index(name="Count"))
        grouped.to_csv(out/"discordance_by_allele_group.csv", index=False)

if __name__ == "__main__":
    main()
