#!/usr/bin/env python3
"""04_patient_level.py
Calculate complete concordance across all six HLA-I alleles per patient.
"""

import argparse
from pathlib import Path
import pandas as pd

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()
    out = Path(args.outdir); out.mkdir(parents=True, exist_ok=True)
    df = pd.read_excel(args.input, sheet_name="detailed")

    rows = []
    for sid, d in df.groupby("SampleID"):
        if set(d["Locus"]) != {"HLA-A","HLA-B","HLA-C"}:
            continue
        rows.append({
            "SampleID": sid,
            "Matching_alleles_4field": int(d["Locus_4digit_matches"].sum()),
            "Matching_alleles_2field": int(d["Locus_2digit_matches"].sum()),
            "Complete_6_allele_concordance_4field": bool(d["Both_alleles_match_4digit"].all()),
            "Complete_6_allele_concordance_2field": bool(d["Both_alleles_match_2digit"].all())
        })

    outdf = pd.DataFrame(rows)
    outdf.to_csv(out/"patient_level_concordance.csv", index=False)

    print("Patients analysed:", len(outdf))
    for c in ["Complete_6_allele_concordance_4field",
              "Complete_6_allele_concordance_2field"]:
        print(c, int(outdf[c].sum()), f"({100*outdf[c].mean():.2f}%)")

if __name__ == "__main__":
    main()
