#!/usr/bin/env python3
"""02_concordance_CI.py
Exact (Clopper-Pearson) 95% CIs for concordance proportions.
"""

import argparse
from pathlib import Path
import pandas as pd
from statsmodels.stats.proportion import proportion_confint

METRICS = {
    "Both alleles, 4-field": "Both_alleles_match_4digit",
    "Any allele, 4-field": "Any_allele_match_4digit",
    "Both alleles, 2-field": "Both_alleles_match_2digit",
    "Any allele, 2-field": "Any_allele_match_2digit",
}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()
    out = Path(args.outdir); out.mkdir(parents=True, exist_ok=True)
    df = pd.read_excel(args.input, sheet_name="detailed")

    rows = []
    groups = [("Overall", df), *[(x, df[df.Locus == x]) for x in ["HLA-A","HLA-B","HLA-C"]]]
    for locus, d in groups:
        for label, col in METRICS.items():
            s = d[col].astype(bool)
            k, n = int(s.sum()), len(s)
            lo, hi = proportion_confint(k, n, alpha=0.05, method="beta")
            rows.append({
                "Locus": locus, "Metric": label, "Concordant": k, "N": n,
                "Percent": round(100*k/n, 2),
                "CI95_lower": round(100*lo, 2),
                "CI95_upper": round(100*hi, 2)
            })
    pd.DataFrame(rows).to_csv(out/"concordance_CI95.csv", index=False)

if __name__ == "__main__":
    main()
