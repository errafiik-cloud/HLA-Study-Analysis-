#!/usr/bin/env python3
"""Generate Figure 1: individual-level germline-to-tumor HLA-I concordance.

Creates a square (1:1) publication figure with two stacked panels:
A = 2-field resolution; B = 4-field resolution.
"""
import argparse
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

FUS = {
    "2-digit": [3, 7, 3, 5, 1, 11, 283],
    "4-digit": [10, 3, 4, 4, 2, 30, 260],
}
TNAC = {
    "2-digit": [0, 1, 2, 3, 0, 2, 75],
    "4-digit": [1, 3, 1, 1, 3, 6, 68],
}

def add_panel(ax, resolution, panel_label):
    x = range(7)
    width = 0.36
    fus = [100*n/313 for n in FUS[resolution]]
    tnac = [100*n/83 for n in TNAC[resolution]]
    b1 = ax.bar([i-width/2 for i in x], fus, width, label="FUSCCTNBC (n = 313)")
    b2 = ax.bar([i+width/2 for i in x], tnac, width, label="TNAC (n = 83)")
    for bars in (b1, b2):
        for bar in bars:
            h = bar.get_height()
            if h > 0:
                ax.annotate(f"{h:.1f}%", (bar.get_x()+bar.get_width()/2, h),
                            xytext=(0, 3), textcoords="offset points",
                            ha="center", va="bottom", fontsize=8)
    ax.text(-0.065, 1.06, panel_label, transform=ax.transAxes,
            fontsize=15, fontweight="bold", va="top", ha="left")
    ax.text(0.06, 1.06, f"({resolution} resolution)", transform=ax.transAxes,
            fontsize=12, fontweight="bold", va="top", ha="left")
    ax.set_ylabel("Individuals (%)")
    ax.set_xticks(range(7))
    ax.set_ylim(0, 100)
    ax.set_yticks(range(0, 101, 20))
    ax.set_xlim(-0.55, 6.55)
    ax.legend(frameon=False, loc="upper left", fontsize=9)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="figures")
    args = ap.parse_args()
    out = Path(args.outdir); out.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(2, 1, figsize=(7.5, 7.5), sharex=True)
    add_panel(axes[0], "2-digit", "A")
    add_panel(axes[1], "4-digit", "B")
    axes[1].set_xlabel("Number of matching alleles (out of 6)")
    fig.suptitle("Individual-level concordance of germline- and tumor-derived HLA-I typing",
                 fontsize=12, y=0.995)
    fig.tight_layout(rect=[0, 0, 1, 0.985])
    fig.savefig(out/"Figure_1_individual_concordance_square.png", dpi=600, bbox_inches="tight")
    fig.savefig(out/"Figure_1_individual_concordance_square.pdf", bbox_inches="tight")
    plt.close(fig)

    rows=[]
    for res in ("2-digit", "4-digit"):
        for dataset, counts, n in (("FUSCCTNBC", FUS[res], 313), ("TNAC", TNAC[res], 83)):
            for m, count in enumerate(counts):
                rows.append([res, dataset, m, count, 100*count/n])
    pd.DataFrame(rows, columns=["Resolution","Dataset","Matching_alleles","N","Percentage"]).to_csv(
        out/"Figure_1_individual_concordance_data.csv", index=False)

if __name__ == "__main__":
    main()
