#!/usr/bin/env python3
"""
08_figure_matching_alleles.py

Reproduce the bar plot showing the percentage of individuals according to
the number of matching HLA-I alleles (0-6).

Input CSV:
    Cohort,Matching_alleles,N,Percent

Example rows:
    FUSCCTNBC,0,2,0.6
    ...
    FUSCCTNBC,6,283,90.4
    TNAC,0,0,0.0
    ...

If Percent is omitted, it is calculated from N within each cohort.

Usage:
python scripts/08_figure_matching_alleles.py \
    --input data/figure_matching_alleles.csv \
    --outdir results
"""

import argparse
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)

    d = pd.read_csv(args.input)

    required = {"Cohort", "Matching_alleles", "N"}
    missing = required - set(d.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")

    d["Matching_alleles"] = pd.to_numeric(d["Matching_alleles"])
    d["N"] = pd.to_numeric(d["N"])

    # Calculate percentages from counts, avoiding rounding errors.
    totals = d.groupby("Cohort")["N"].transform("sum")
    d["Percent_calculated"] = 100 * d["N"] / totals

    # Preserve the displayed percentages when supplied; otherwise use calculated.
    if "Percent" in d.columns:
        d["Percent"] = pd.to_numeric(d["Percent"])
    else:
        d["Percent"] = d["Percent_calculated"]

    d = d[d["Matching_alleles"].between(0, 6)].copy()

    # Ensure all seven categories are present for each cohort.
    cohorts = ["FUSCCTNBC", "TNAC"]
    categories = np.arange(7)

    fig, ax = plt.subplots(figsize=(9, 5.2))
    width = 0.34

    for offset, cohort in zip([-width/2, width/2], cohorts):
        sub = (d[d["Cohort"] == cohort]
               .set_index("Matching_alleles")
               .reindex(categories, fill_value=0))

        bars = ax.bar(
            categories + offset,
            sub["Percent"].values,
            width=width,
            label=f"{cohort} (n = {int(sub['N'].sum())})"
        )

        for bar in bars:
            h = bar.get_height()
            if h > 0:
                ax.annotate(
                    f"{h:.1f}%",
                    xy=(bar.get_x() + bar.get_width()/2, h),
                    xytext=(0, 3),
                    textcoords="offset points",
                    ha="center",
                    va="bottom",
                    fontsize=9
                )

    ax.set_xlabel("Number of matching alleles (out of 6)")
    ax.set_ylabel("Individuals (%)")
    ax.set_xticks(categories)
    ax.set_xlim(-0.55, 6.55)
    ax.set_ylim(0, 100)
    ax.legend(frameon=False, loc="upper left")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    fig.tight_layout()
    fig.savefig(out/"Figure_matching_alleles.png", dpi=600, bbox_inches="tight")
    fig.savefig(out/"Figure_matching_alleles.pdf", bbox_inches="tight")
    plt.close(fig)

    d.to_csv(out/"figure_matching_alleles_summary.csv", index=False)


if __name__ == "__main__":
    main()
